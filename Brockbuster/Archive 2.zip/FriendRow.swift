import SwiftUI

struct FriendRow: View {
    let item: BrockbusterAPI.FriendsPayload.FriendItem

    var body: some View {
        HStack(spacing: 12) {
            Circle()
                .fill(Color.gray.opacity(0.3))
                .frame(width: 40, height: 40)

            VStack(alignment: .leading) {
                Text(item.user.displayName)
                    .font(BrockbusterTheme.Fonts.body)

                Text(item.status.capitalized)
                    .font(BrockbusterTheme.Fonts.caption)
                    .foregroundColor(.secondary)
            }

            Spacer()
        }
    }
}
