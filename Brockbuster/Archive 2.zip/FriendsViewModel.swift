import Foundation
import SwiftUI

@MainActor
final class FriendsViewModel: ObservableObject {

    @Published var isLoading = false
    @Published var errorMessage: String? = nil

    @Published var pending: [BrockbusterAPI.FriendsPayload.FriendItem] = []
    @Published var friends: [BrockbusterAPI.FriendsPayload.FriendItem] = []

    func load(session: SessionStore) async {
        guard
            let token = session.jellyfinAccessToken,
            let userId = session.jellyfinUserId
        else {
            errorMessage = "Not logged in."
            return
        }

        isLoading = true
        errorMessage = nil

        do {
            let payload = try await BrockbusterAPI.shared.fetchFriends(
                jellyfinToken: token,
                jellyfinUserId: userId
            )

            pending = payload.pending ?? []
            friends = payload.friends ?? []

        } catch {
            errorMessage = error.localizedDescription
        }

        isLoading = false
    }
}
